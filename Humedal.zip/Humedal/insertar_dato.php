<?php
header('Content-Type: application/json');
include("Conexion.php");

$response = array();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {

  if (isset($_POST['valor']) && isset($_POST['id_sensor']) && isset($_POST['id_tipo_dato'])) {

    $valor = floatval($_POST['valor']);
    $id_sensor = intval($_POST['id_sensor']);
    $id_tipo_dato = intval($_POST['id_tipo_dato']);

    if ($id_tipo_dato === 1) {
      if ($valor < -50 || $valor > 150) {
        $response['success'] = false;
        $response['message'] = "Valor de temperatura fuera de rango.";
        echo json_encode($response);
        exit();
      }
    } elseif ($id_tipo_dato === 2) {
      if ($valor < 0 || $valor > 100) {
        $response['success'] = false;
        $response['message'] = "Valor de humedad fuera de rango.";
        echo json_encode($response);
        exit();
      }
    } else {
      $response['success'] = false;
      $response['message'] = "id_tipo_dato no válido.";
      echo json_encode($response);
      exit();
    }

    $stmt_verify = $conn->prepare("SELECT id_sensor FROM sensores WHERE id_sensor = ?");
    if ($stmt_verify) {
      $stmt_verify->bind_param("i", $id_sensor);
      $stmt_verify->execute();
      $stmt_verify->store_result();

      if ($stmt_verify->num_rows > 0) {
        $stmt_verify->close();

        $stmt = $conn->prepare("INSERT INTO datos_sensores (id_sensor, id_tipo_dato, valor, fecha) VALUES (?, ?, ?, NOW())");
        if ($stmt) {
          $stmt->bind_param("iid", $id_sensor, $id_tipo_dato, $valor);

          if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = "Nuevo registro creado exitosamente desde POST.";
          } else {
            $response['success'] = false;
            $response['message'] = "Error al ejecutar la consulta POST: " . $stmt->error;
          }

          $stmt->close();
        } else {
          $response['success'] = false;
          $response['message'] = "Error al preparar la sentencia POST: " . $conn->error;
        }
      } else {
        $response['success'] = false;
        $response['message'] = "id_sensor no encontrado.";
        $stmt_verify->close();
      }
    } else {
      $response['success'] = false;
      $response['message'] = "Error al preparar la sentencia para verificar sensor: " . $conn->error;
    }
  } else {
    $response['success'] = false;
    $response['message'] = "Datos insuficientes en la solicitud POST.";
  }
} else {
  $response['success'] = false;
  $response['message'] = "Método HTTP no soportado. Solo se acepta POST.";
}

$conn->close();

echo json_encode($response);
?>