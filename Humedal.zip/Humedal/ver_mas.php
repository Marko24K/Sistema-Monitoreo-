<?php
include "Conexion.php";

function sanitizeInput($data)
{
    return htmlspecialchars(stripslashes(trim($data)));
}

$dato = isset($_GET['dato']) ? sanitizeInput($_GET['dato']) : '';

if (!in_array($dato, ['Temperatura', 'Humedad'])) {
    header("Location: index.php");
    exit();
}

$query_tipo_dato = "SELECT id_tipo_dato, unidad FROM tipos_datos WHERE nombre_tipo_dato = ?";
$stmt_tipo_dato = $conn->prepare($query_tipo_dato);
$stmt_tipo_dato->bind_param("s", $dato);
$stmt_tipo_dato->execute();
$result_tipo_dato = $stmt_tipo_dato->get_result();

if ($result_tipo_dato->num_rows === 0) {
    header("Location: index.php");
    exit();
}

$row_tipo_dato = $result_tipo_dato->fetch_assoc();
$id_tipo_dato = $row_tipo_dato['id_tipo_dato'];
$unidad = $row_tipo_dato['unidad'];

$query_datos = "
    SELECT ds.valor, ds.fecha, s.nombre_sensor, s.tipo_sensor 
    FROM datos_sensores ds
    JOIN sensores s ON ds.id_sensor = s.id_sensor
    WHERE ds.id_tipo_dato = ?
    ORDER BY ds.fecha DESC
";
$stmt_datos = $conn->prepare($query_datos);
$stmt_datos->bind_param("i", $id_tipo_dato);
$stmt_datos->execute();
$result_datos = $stmt_datos->get_result();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Ver Más - Monitoreo de Humedal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="img/icon.webp">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/moment@2.29.4/min/moment.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-moment@1.0.0"></script>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/ver.css">
</head>

<body>
    <header class="header">
        <div class="container">
            <img src="img/logoupla.png" alt="Logo UPLA" width="100" class="mb-3">
            <h1>Monitoreo de Humedal</h1>
            <p>Sistema de Control y Gestión de Calidad del Agua</p>
        </div>
    </header>

    <main class="container my-4">
        <section class="mb-5">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h2 class="text-primary"><?php echo htmlspecialchars($dato); ?> - Datos Detallados</h2>
                <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-left me-2"></i> Volver al
                    Inicio</a>
            </div>
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-primary">
                                <tr>
                                    <th>Valor (<?php echo htmlspecialchars($unidad); ?>)</th>
                                    <th>Fecha</th>
                                    <th>Sensor</th>
                                    <th>Tipo de Sensor</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($result_datos->num_rows > 0): ?>
                                    <?php while ($row = $result_datos->fetch_assoc()): ?>
                                        <tr>
                                            <td><?php echo number_format($row['valor'], 2); ?>
                                                <?php echo htmlspecialchars($unidad); ?>
                                            </td>
                                            <td><?php echo date('d/m/Y H:i', strtotime($row['fecha'])); ?></td>
                                            <td><?php echo htmlspecialchars($row['nombre_sensor']); ?></td>
                                            <td><?php echo htmlspecialchars($row['tipo_sensor']); ?></td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4" class="text-center">No hay datos disponibles.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>

        <section class="mb-5">
            <h2 class="mb-4 text-primary">Visualización Detallada</h2>
            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title mb-3 text-primary">
                        <i class="fas fa-chart-line me-2"></i> <?php echo htmlspecialchars($dato); ?> - Gráfica
                        Detallada
                    </h5>
                    <canvas id="detailedChart" height="400"></canvas>
                </div>
            </div>
        </section>
    </main>

    <footer class="bg-primary text-white py-4">
        <div class="container text-center">
            <p class="mb-2">&copy; 2024 Universidad de Playa Ancha.</p>
            <img src="img/logoupla.png" alt="logo UPLA" width="80">
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const dato = "<?php echo addslashes($dato); ?>";
            const unidad = "<?php echo addslashes($unidad); ?>";
            const labels = [
                <?php
                $stmt_datos->execute();
                $result_datos = $stmt_datos->get_result();
                $datos_grafica = [];
                while ($row = $result_datos->fetch_assoc()) {
                    $fecha = date('Y-m-d H:i:s', strtotime($row['fecha']));
                    $valor = floatval($row['valor']);
                    $datos_grafica[] = ['fecha' => $fecha, 'valor' => $valor];
                }
                usort($datos_grafica, function ($a, $b) {
                    return strtotime($a['fecha']) - strtotime($b['fecha']);
                });
                foreach ($datos_grafica as $data_point) {
                    echo "'" . $data_point['fecha'] . "',";
                }
                ?>
            ];

            const dataValues = [
                <?php
                foreach ($datos_grafica as $data_point) {
                    echo $data_point['valor'] . ",";
                }
                ?>
            ];

            const ctx = document.getElementById('detailedChart').getContext('2d');
            const detailedChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: '<?php echo htmlspecialchars($dato); ?> (<?php echo htmlspecialchars($unidad); ?>)',
                        data: dataValues,
                        borderColor: 'rgba(0, 51, 102, 1)',
                        backgroundColor: 'rgba(0, 51, 102, 0.2)',
                        fill: true,
                        tension: 0.3
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        x: {
                            type: 'time',
                            time: {
                                unit: 'day',
                                tooltipFormat: 'DD/MM/YYYY HH:mm',
                                displayFormats: {
                                    day: 'DD/MM'
                                }
                            },
                            title: {
                                display: true,
                                text: 'Fecha'
                            }
                        },
                        y: {
                            beginAtZero: false,
                            title: {
                                display: true,
                                text: '<?php echo htmlspecialchars($dato); ?> (<?php echo htmlspecialchars($unidad); ?>)'
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: true,
                            position: 'top',
                        },
                        tooltip: {
                            mode: 'index',
                            intersect: false,
                        }
                    },
                    interaction: {
                        mode: 'nearest',
                        axis: 'x',
                        intersect: false
                    }
                }
            });
        });
    </script>
</body>

</html>

<?php
$stmt_datos->close();
$stmt_tipo_dato->close();
$conn->close();
?>