<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "humedal";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
if (basename(__FILE__) == basename($_SERVER["SCRIPT_FILENAME"])) {
    echo "Conexión exitosa";
}
?>