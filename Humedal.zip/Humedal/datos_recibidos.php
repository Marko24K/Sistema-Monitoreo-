<?php
include "Conexion.php";

$sql = "SELECT ds.id_dato, ds.valor, ds.fecha, s.nombre_sensor, s.tipo_sensor, td.nombre_tipo_dato, td.unidad
        FROM datos_sensores ds
        JOIN sensores s ON ds.id_sensor = s.id_sensor
        JOIN tipos_datos td ON ds.id_tipo_dato = td.id_tipo_dato
        ORDER BY ds.fecha DESC";

$result = $conn->query($sql);

$data = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $row['fecha'] = date('Y-m-d H:i:s', strtotime($row['fecha']));
        $data[] = $row;
    }
}

echo json_encode($data);

$conn->close();
?>